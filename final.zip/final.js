let commentContainer = document.getElementById("comment-container");

function createInputBox() {
  let div = document.createElement("div");
  div.setAttribute("class", "comment-details");

  div.innerHTML += `
    <input type="text" placeholder="Add your reply" class="input" />
    <button class="btn submit">Submit</button>`;
  return div;
}
// let addeddiv = document.getElementById("addeddiv");
// function createInputBox1(){
//   let div = document.createElement("div");
//   div.innerHTML +=`<div class="all-comment" id="addeddiv">
//         <div class="card1">
//             <span class="text1">New Comment</span>
//             <p id="selected-text1"></p>
//             <span id="reply1" class="reply1">Add Reply</span>
            
//         </div>
//     </div>`;
//     return div;
// }
// addeddiv.addEventListener("click", function (e){
//   let addcommentsClicked = e.target.classList.contains("newcomment");
//   if (addcommentsClicked) {
//     closestCard.appendChild(createInputBox1());
//   }

// });

function addReply(text) {
  let div = document.createElement("div");
  div.setAttribute("class", "all-comment");

  div.innerHTML += `
    <div class="card">
      <span class="text">${text}</span>
    </div>`;
  return div;
}

commentContainer.addEventListener("click", function (e) {
  let replyClicked = e.target.classList.contains("reply");
  let submitClicked = e.target.classList.contains("submit");
  let closestCard = e.target.closest(".all-comment");

  console.log(replyClicked,"replyClicked");
  console.log(submitClicked,"submitClicked");
  console.log(closestCard,"closestCard");



//if reply is clicked add input box
  if (replyClicked) {
    closestCard.appendChild(createInputBox());
  }

  if (submitClicked) {
    const commentDetails = e.target.closest(".comment-details");
    console.log(commentDetails,"commentDetailssssssssssssssssssssssssssss");
    if (commentDetails.children[0].value) {
      closestCard.appendChild(addReply(commentDetails.children[0].value));
      commentDetails.remove();
    }
  }
});

var text_h4 = document.getElementById("article-text");
var selectedText_p = document.getElementById("selected-text");
console.log(selectedText_p,"selectedText_p select value");


  text_h4.addEventListener('mouseup', () => {
    let selection = window.getSelection();

    console.log(selection,"on mouse hoveer");
    console.log(text_h4,"text hr");


    selectedText_p.textContent = selection.toString();


  });
function addcomment() {
  var x = document.getElementById("addeddiv");
  console.log(x,"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
var text_h3 = document.getElementsByClassName("article-text");
var selectedText_para = document.getElementById("selected-text1");

text_h3.addEventListener('mouseup', () => {
  let selection = window.getSelection();
  selectedText_para.textContent = selection.toString();
});

